package util;

import java.sql.ResultSet;

public interface RowMap {
    Object getRowmap(ResultSet res);
}
