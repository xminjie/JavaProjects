package action;

import entity.AdminUser;
import entity.Flight;
import entity.User;

public class Who {
    public static User user = new User();
    public static AdminUser adminUser = new AdminUser();
    public static Flight flight = new Flight();

}
